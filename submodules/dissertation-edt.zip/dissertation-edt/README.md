# dissertation-edt

## Setup Notes

TeX packages to install:

- tex-gyre
